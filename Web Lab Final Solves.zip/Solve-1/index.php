<!DOCTYPE html>
<html>
  <body>
	<form method="post" action="process.php">
		name:<br>
		<input type="text" name="name">
		<br>
		id:<br>
		<input type="id" name="id">
		<br>
		age:<br>
		<input type="text" name="age">
		<br>
		user_name:<br>
		<input type="text" name="user_name">
		<br>
		password:<br>
		<input type="text" name="password">
		<br>
		<br>
		<input type="submit" name="save" value="submit">
	</form>

	</table>
  </body>
</html>