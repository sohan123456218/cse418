<?php
for($row=1;$row<=5;$row++)
{
   for ($star=1;$star<=$row;$star++)
    {
     echo "*";
     }
 echo "<br>";
}
?>